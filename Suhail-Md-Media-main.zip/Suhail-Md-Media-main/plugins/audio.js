/**

//══════════════════════════════════════════════════════════════════════════════════════════════════════//
//                                                                                                      //
//                                ＷＨＡＴＳＡＰＰ ＢＯＴ－ＭＤ ＢＥＴＡ                                   //
//                                                                                                      // 
//                                         Ｖ：1．2．2                                                   // 
//                                                                                                      // 
//            ███████╗██╗   ██╗██╗  ██╗ █████╗ ██╗██╗         ███╗   ███╗██████╗                        //
//            ██╔════╝██║   ██║██║  ██║██╔══██╗██║██║         ████╗ ████║██╔══██╗                       //
//            ███████╗██║   ██║███████║███████║██║██║         ██╔████╔██║██║  ██║                       //
//            ╚════██║██║   ██║██╔══██║██╔══██║██║██║         ██║╚██╔╝██║██║  ██║                       //
//            ███████║╚██████╔╝██║  ██║██║  ██║██║███████╗    ██║ ╚═╝ ██║██████╔╝                       //
//            ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝    ╚═╝     ╚═╝╚═════╝                        //
//                                                                                                      //
//                                                                                                      //
//                                                                                                      //
//══════════════════════════════════════════════════════════════════════════════════════════════════════//

CURRENTLY RUNNING ON BETA VERSION!!
*
   * @project_name : Suhail-Md
   * @author : Suhail Tech Info
   * @youtube : https://www.youtube.com/c/@SuhailTechInfo
   * @infoription : Suhail-Md ,A Multi-functional whatsapp user bot.
   * @version 1.2.2 
*
   * Licensed under the  GPL-3.0 License;
* 
   * ┌┤Created By Suhail Tech Info.
   * © 2023 Suhail-Md ✭ ⛥.
   * plugin date : 11/18/2023
* 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
**/
let SuhailTechInfo = "Owner";





const _0x5ae29e=_0xf3eb;(function(_0x3001af,_0x41420c){const _0x5078a0=_0xf3eb,_0x3e9d0b=_0x3001af();while(!![]){try{const _0x36b6e2=parseInt(_0x5078a0(0x1a5))/0x1*(parseInt(_0x5078a0(0x1a8))/0x2)+-parseInt(_0x5078a0(0x1b5))/0x3+-parseInt(_0x5078a0(0x196))/0x4*(-parseInt(_0x5078a0(0x19e))/0x5)+-parseInt(_0x5078a0(0x191))/0x6*(parseInt(_0x5078a0(0x1aa))/0x7)+parseInt(_0x5078a0(0x19c))/0x8*(-parseInt(_0x5078a0(0x193))/0x9)+parseInt(_0x5078a0(0x195))/0xa*(parseInt(_0x5078a0(0x1ab))/0xb)+parseInt(_0x5078a0(0x1ad))/0xc*(parseInt(_0x5078a0(0x1ae))/0xd);if(_0x36b6e2===_0x41420c)break;else _0x3e9d0b['push'](_0x3e9d0b['shift']());}catch(_0x16dccf){_0x3e9d0b['push'](_0x3e9d0b['shift']());}}}(_0x34b9,0x5391b));function _0xf3eb(_0x361163,_0xc7fc16){const _0x34b93b=_0x34b9();return _0xf3eb=function(_0xf3ebe0,_0x504611){_0xf3ebe0=_0xf3ebe0-0x191;let _0x3e8f3e=_0x34b93b[_0xf3ebe0];return _0x3e8f3e;},_0xf3eb(_0x361163,_0xc7fc16);}function _0x34b9(){const _0x2ebca6=['adds\x20fat\x20in\x20given\x20sound','adds\x20earrape\x20in\x20given\x20sound','fat','155599lnOrUd','adds\x20slow\x20in\x20given\x20sound','\x20\x0a\x0aCommand:\x20','2wpZgGs','smooth','278929GPAJNW','73106tsRmwL','adds\x20blown\x20in\x20given\x20sound','120RUDovK','944606uxitgM','audio','adds\x20robot\x20in\x20given\x20sound','earrape','error','robot','bass','1287549PiWfcx','adds\x20fast\x20in\x20given\x20sound','66VBYUEK','nightcore','9OvubCu','reverse','70VAqTea','89128OpcKDn','deep','adds\x20reverse\x20in\x20given\x20sound','adds\x20smooth\x20in\x20given\x20sound','adds\x20nightcore\x20in\x20given\x20sound','adds\x20bass\x20in\x20given\x20sound','425376DWTHdj','adds\x20tupai\x20in\x20given\x20sound','75HPBzaK','<reply\x20to\x20any\x20audio>','fast','tupai'];_0x34b9=function(){return _0x2ebca6;};return _0x34b9();}const {tlang,smd,audioEditor}=require('../lib'),fs=require('fs');smd({'cmdname':_0x5ae29e(0x1b4),'info':_0x5ae29e(0x19b),'type':_0x5ae29e(0x1af),'use':'<reply\x20to\x20any\x20audio>'},async(_0x5d6ad1,_0x53c461,{smd:_0xf17388})=>{const _0x26a83e=_0x5ae29e;try{return await audioEditor(_0x5d6ad1,_0xf17388,_0x5d6ad1);}catch(_0x429687){return await _0x5d6ad1[_0x26a83e(0x1b2)](_0x429687+_0x26a83e(0x1a7)+_0xf17388,_0x429687);}}),smd({'cmdname':'blown','info':_0x5ae29e(0x1ac),'type':_0x5ae29e(0x1af),'use':_0x5ae29e(0x19f)},async(_0x483202,_0x13c66b,{smd:_0x4afb5c})=>{try{return await audioEditor(_0x483202,_0x4afb5c,_0x483202);}catch(_0x370dd7){return await _0x483202['error'](_0x370dd7+'\x20\x0a\x0aCommand:\x20'+_0x4afb5c,_0x370dd7);}}),smd({'cmdname':_0x5ae29e(0x197),'info':'adds\x20deep\x20in\x20given\x20sound','type':_0x5ae29e(0x1af),'use':'<reply\x20to\x20any\x20audio>'},async(_0x4f23d9,_0x3cf305,{smd:_0x7e1b7})=>{const _0x3a6b03=_0x5ae29e;try{return await audioEditor(_0x4f23d9,_0x7e1b7,_0x4f23d9);}catch(_0x212449){return await _0x4f23d9[_0x3a6b03(0x1b2)](_0x212449+_0x3a6b03(0x1a7)+_0x7e1b7,_0x212449);}}),smd({'cmdname':_0x5ae29e(0x1b1),'info':_0x5ae29e(0x1a3),'type':_0x5ae29e(0x1af),'use':_0x5ae29e(0x19f)},async(_0x17a00c,_0x54b87c,{smd:_0x22851d})=>{const _0x36392c=_0x5ae29e;try{return await audioEditor(_0x17a00c,_0x22851d,_0x17a00c);}catch(_0x1069a9){return await _0x17a00c['error'](_0x1069a9+_0x36392c(0x1a7)+_0x22851d,_0x1069a9);}}),smd({'cmdname':_0x5ae29e(0x1a0),'info':_0x5ae29e(0x1b6),'type':_0x5ae29e(0x1af),'use':_0x5ae29e(0x19f)},async(_0x329304,_0x290150,{smd:_0x555cf0})=>{const _0x1d0046=_0x5ae29e;try{return await audioEditor(_0x329304,_0x555cf0,_0x329304);}catch(_0x2e5829){return await _0x329304[_0x1d0046(0x1b2)](_0x2e5829+_0x1d0046(0x1a7)+_0x555cf0,_0x2e5829);}}),smd({'cmdname':_0x5ae29e(0x1a4),'info':_0x5ae29e(0x1a2),'type':_0x5ae29e(0x1af),'use':'<reply\x20to\x20any\x20audio>'},async(_0x4e50f6,_0x5469bf,{smd:_0x210909})=>{const _0x4949c0=_0x5ae29e;try{return await audioEditor(_0x4e50f6,_0x210909,_0x4e50f6);}catch(_0x2d03a6){return await _0x4e50f6[_0x4949c0(0x1b2)](_0x2d03a6+_0x4949c0(0x1a7)+_0x210909,_0x2d03a6);}}),smd({'cmdname':_0x5ae29e(0x192),'info':_0x5ae29e(0x19a),'type':_0x5ae29e(0x1af),'use':'<reply\x20to\x20any\x20audio>'},async(_0x562f14,_0x4de080,{smd:_0x3887ce})=>{const _0x30bcf1=_0x5ae29e;try{return await audioEditor(_0x562f14,_0x3887ce,_0x562f14);}catch(_0x1c2061){return await _0x562f14[_0x30bcf1(0x1b2)](_0x1c2061+_0x30bcf1(0x1a7)+_0x3887ce,_0x1c2061);}}),smd({'cmdname':_0x5ae29e(0x194),'info':_0x5ae29e(0x198),'type':_0x5ae29e(0x1af),'use':_0x5ae29e(0x19f)},async(_0x362707,_0xcb10cd,{smd:_0x5223dd})=>{try{return await audioEditor(_0x362707,_0x5223dd,_0x362707);}catch(_0x5ee99a){return await _0x362707['error'](_0x5ee99a+'\x20\x0a\x0aCommand:\x20'+_0x5223dd,_0x5ee99a);}}),smd({'cmdname':_0x5ae29e(0x1b3),'info':_0x5ae29e(0x1b0),'type':'audio','use':_0x5ae29e(0x19f)},async(_0x310526,_0x4716ec,{smd:_0xa9fd5})=>{const _0x2fab43=_0x5ae29e;try{return await audioEditor(_0x310526,_0xa9fd5,_0x310526);}catch(_0x552466){return await _0x310526[_0x2fab43(0x1b2)](_0x552466+_0x2fab43(0x1a7)+_0xa9fd5,_0x552466);}}),smd({'cmdname':'slow','info':_0x5ae29e(0x1a6),'type':_0x5ae29e(0x1af),'use':_0x5ae29e(0x19f)},async(_0x4a8426,_0x4b49bd,{smd:_0x181538})=>{const _0x3645d1=_0x5ae29e;try{return await audioEditor(_0x4a8426,_0x181538,_0x4a8426);}catch(_0x489533){return await _0x4a8426[_0x3645d1(0x1b2)](_0x489533+'\x20\x0a\x0aCommand:\x20'+_0x181538,_0x489533);}}),smd({'cmdname':_0x5ae29e(0x1a9),'info':_0x5ae29e(0x199),'type':_0x5ae29e(0x1af),'use':_0x5ae29e(0x19f)},async(_0x40e425,_0x2b44c9,{smd:_0x4894c8})=>{const _0x388a5a=_0x5ae29e;try{return await audioEditor(_0x40e425,_0x4894c8,_0x40e425);}catch(_0x346685){return await _0x40e425['error'](_0x346685+_0x388a5a(0x1a7)+_0x4894c8,_0x346685);}}),smd({'cmdname':_0x5ae29e(0x1a1),'info':_0x5ae29e(0x19d),'type':_0x5ae29e(0x1af),'use':_0x5ae29e(0x19f)},async(_0x206b7,_0x3d2b22,{smd:_0x1f70bd})=>{const _0xa5099e=_0x5ae29e;try{return await audioEditor(_0x206b7,_0x1f70bd,_0x206b7);}catch(_0x2f0862){return await _0x206b7[_0xa5099e(0x1b2)](_0x2f0862+_0xa5099e(0x1a7)+_0x1f70bd,_0x2f0862);}});

/*
{
   pattern: "audio",
   type: "notes",
}
 */


