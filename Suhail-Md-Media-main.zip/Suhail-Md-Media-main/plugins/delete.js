/**

//══════════════════════════════════════════════════════════════════════════════════════════════════════//
//                                                                                                      //
//                                ＷＨＡＴＳＡＰＰ ＢＯＴ－ＭＤ ＢＥＴＡ                                   //
//                                                                                                      // 
//                                         Ｖ：1．2．2                                                   // 
//                                                                                                      // 
//            ███████╗██╗   ██╗██╗  ██╗ █████╗ ██╗██╗         ███╗   ███╗██████╗                        //
//            ██╔════╝██║   ██║██║  ██║██╔══██╗██║██║         ████╗ ████║██╔══██╗                       //
//            ███████╗██║   ██║███████║███████║██║██║         ██╔████╔██║██║  ██║                       //
//            ╚════██║██║   ██║██╔══██║██╔══██║██║██║         ██║╚██╔╝██║██║  ██║                       //
//            ███████║╚██████╔╝██║  ██║██║  ██║██║███████╗    ██║ ╚═╝ ██║██████╔╝                       //
//            ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝    ╚═╝     ╚═╝╚═════╝                        //
//                                                                                                      //
//                                                                                                      //
//                                                                                                      //
//══════════════════════════════════════════════════════════════════════════════════════════════════════//

CURRENTLY RUNNING ON BETA VERSION!!
*
   * @project_name : Suhail-Md
   * @author : Suhail Tech Info
   * @youtube : https://www.youtube.com/c/@SuhailTechInfo
   * @infoription : Suhail-Md ,A Multi-functional whatsapp user bot.
   * @version 1.2.2 
*
   * Licensed under the  GPL-3.0 License;
* 
   * ┌┤Created By Suhail Tech Info.
   * © 2023 Suhail-Md ✭ ⛥.
   * plugin date : 11/18/2023
* 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
**/


let SuhailTechInfo = "Owner";
let DELCHAT = process.env.DELCHAT || "pm"; // "chat"
/*
cmd({
   pattern :"delete",
   desc: "downloads deleted messages",
   category: "delete",
   use:"< message >",
   filename: __filename,
}
 */



const _0x464915=_0x2811;(function(_0x2a642a,_0x1309b5){const _0x549530=_0x2811,_0x3acb9f=_0x2a642a();while(!![]){try{const _0x3d9904=-parseInt(_0x549530(0x14d))/0x1+parseInt(_0x549530(0x152))/0x2*(-parseInt(_0x549530(0x15f))/0x3)+parseInt(_0x549530(0x149))/0x4+-parseInt(_0x549530(0x177))/0x5+parseInt(_0x549530(0x156))/0x6*(parseInt(_0x549530(0x164))/0x7)+parseInt(_0x549530(0x154))/0x8+parseInt(_0x549530(0x148))/0x9;if(_0x3d9904===_0x1309b5)break;else _0x3acb9f['push'](_0x3acb9f['shift']());}catch(_0x555e23){_0x3acb9f['push'](_0x3acb9f['shift']());}}}(_0x1778,0xc24cd));const {smd,tlang,botpic,prefix,Config,bot_}=require(_0x464915(0x162));function _0x2811(_0x209805,_0x4eeb18){const _0x177854=_0x1778();return _0x2811=function(_0x2811ac,_0x1f9d09){_0x2811ac=_0x2811ac-0x144;let _0x4052c9=_0x177854[_0x2811ac];return _0x4052c9;},_0x2811(_0x209805,_0x4eeb18);}function _0x1778(){const _0x526739=['5001540lDJaTz','\x0a*MESSGE\x20FROM:*\x20@','messages','senderNum','477008ENpYDC','key','*_Use\x20on/off\x20to\x20enable/disable\x20Anti_Delete!_*','general','conversation','14Unfiqi','reply','11287368XVjYZc','*Anti_Delete\x20Succesfully\x20enabled*','12rSoRDU','updateOne','join','trim','true','new','msg','delete','*[DELETED\x20INFORMATION]*\x0a\x0a*TIME:*\x20','534825oGXpJR','\x0a\x0aCommand:\x20antidelete\x20','false','../lib','bot','480543lNACqF','from','time','send','length','bot_','\x0a*CHAT:*\x20','*[ANTIDELETE\x20DETECTED]*','*Anti_Delete\x20already\x20disabled*','split','test','error','user','*Anti_Delete\x20Succesfully\x20deactivated*','act','getName','*Anti_Delete\x20already\x20enabled!*','toLowerCase','participant','3171155gRNxPI','off','message','enable','antidelete','log','\x0a*DELETED\x20BY:*\x20@','chat','<on/off>','fakeMessage','findOne','3207717iggfBP'];_0x1778=function(){return _0x526739;};return _0x1778();}let bgmm=![];smd({'pattern':'antidelete','alias':[_0x464915(0x15d)],'desc':'turn\x20On/Off\x20auto\x20download\x20deletes','fromMe':!![],'category':_0x464915(0x150),'use':_0x464915(0x145),'filename':__filename},async(_0x17cbbb,_0x32fa8b)=>{const _0x1cccb9=_0x464915;try{bgmm=await bot_[_0x1cccb9(0x147)]({'id':_0x1cccb9(0x169)+_0x17cbbb['user']})||await bot_[_0x1cccb9(0x15b)]({'id':_0x1cccb9(0x169)+_0x17cbbb[_0x1cccb9(0x170)]});let _0x649c1d=_0x32fa8b[_0x1cccb9(0x175)]()[_0x1cccb9(0x16d)]('\x20')[0x0][_0x1cccb9(0x159)]();if(_0x649c1d==='on'||_0x649c1d===_0x1cccb9(0x17a)||_0x649c1d===_0x1cccb9(0x172)){if(bgmm[_0x1cccb9(0x17b)]===_0x1cccb9(0x15a))return await _0x17cbbb[_0x1cccb9(0x153)](_0x1cccb9(0x174));return await bot_[_0x1cccb9(0x157)]({'id':_0x1cccb9(0x169)+_0x17cbbb[_0x1cccb9(0x170)]},{'antidelete':_0x1cccb9(0x15a)}),await _0x17cbbb[_0x1cccb9(0x153)](_0x1cccb9(0x155));}else{if(_0x649c1d===_0x1cccb9(0x178)||_0x649c1d==='disable'||_0x649c1d==='deact'){if(bgmm[_0x1cccb9(0x17b)]===_0x1cccb9(0x161))return await _0x17cbbb[_0x1cccb9(0x153)](_0x1cccb9(0x16c));return await bot_[_0x1cccb9(0x157)]({'id':_0x1cccb9(0x169)+_0x17cbbb[_0x1cccb9(0x170)]},{'antidelete':_0x1cccb9(0x161)}),await _0x17cbbb[_0x1cccb9(0x153)](_0x1cccb9(0x171));}else return await _0x17cbbb[_0x1cccb9(0x167)](_0x1cccb9(0x14f));}}catch(_0x29fc10){await _0x17cbbb[_0x1cccb9(0x16f)](_0x29fc10+_0x1cccb9(0x160),_0x29fc10);}});let ms=[],{stor,isGroup}=require(_0x464915(0x162));smd({'on':_0x464915(0x15d)},async(_0x52ff57,_0x12aaf9,{store:_0x33e289})=>{const _0x34cf85=_0x464915;try{let _0x2e7880=await bot_[_0x34cf85(0x147)]({'id':'bot_'+_0x52ff57[_0x34cf85(0x170)]});if(_0x2e7880&&_0x2e7880['antidelete']&&_0x2e7880[_0x34cf85(0x17b)]===_0x34cf85(0x15a)){let _0x4a4a8f=_0x52ff57[_0x34cf85(0x15c)]['key'][_0x34cf85(0x176)]?_0x52ff57[_0x34cf85(0x15c)][_0x34cf85(0x14e)]['participant']:_0x52ff57[_0x34cf85(0x15c)]['key']['fromMe']?_0x52ff57['user']:_0x52ff57['msg'][_0x34cf85(0x14e)]['remoteJid'],_0x1ea1c0=await stor();!_0x1ea1c0['messages'][_0x52ff57['from']]&&(_0x1ea1c0[_0x34cf85(0x14b)][_0x52ff57[_0x34cf85(0x165)]]={});ms=[..._0x1ea1c0[_0x34cf85(0x14b)][_0x52ff57[_0x34cf85(0x165)]],..._0x33e289[_0x34cf85(0x14b)][_0x52ff57[_0x34cf85(0x165)]]['array']];for(let _0x3597d4=0x0;_0x3597d4<ms[_0x34cf85(0x168)];_0x3597d4++){if(ms[_0x3597d4][_0x34cf85(0x14e)]['id']===_0x52ff57['msg'][_0x34cf85(0x14e)]['id']){let _0x4d822f=await _0x52ff57[_0x34cf85(0x163)][_0x34cf85(0x146)]('text',{'id':_0x52ff57[_0x34cf85(0x15c)][_0x34cf85(0x14e)]['id']},_0x34cf85(0x16b)),_0x52c1e8=await _0x52ff57[_0x34cf85(0x163)]['forwardOrBroadCast'](/pm/gi[_0x34cf85(0x16e)](DELCHAT)?_0x52ff57[_0x34cf85(0x170)]:_0x52ff57['from'],ms[_0x3597d4][_0x34cf85(0x179)],{'quoted':ms[_0x3597d4][_0x34cf85(0x179)]&&ms[_0x3597d4][_0x34cf85(0x179)][_0x34cf85(0x151)]?undefined:_0x4d822f});if(_0x52c1e8)await _0x52ff57[_0x34cf85(0x163)]['sendMessage'](/pm/gi[_0x34cf85(0x16e)](DELCHAT)?_0x52ff57['user']:_0x52ff57[_0x34cf85(0x165)],{'text':_0x34cf85(0x15e)+_0x52ff57[_0x34cf85(0x166)]+_0x34cf85(0x16a)+(await _0x52ff57[_0x34cf85(0x163)][_0x34cf85(0x173)](_0x52ff57[_0x34cf85(0x144)]))[_0x34cf85(0x16d)]('\x0a')[_0x34cf85(0x158)]('\x20\x20')+_0x34cf85(0x17d)+_0x52ff57[_0x34cf85(0x14c)]+_0x34cf85(0x14a)+_0x4a4a8f['split']('@')[0x0],'mentions':[_0x4a4a8f,_0x52ff57['sender']]},{'quoted':_0x52c1e8});break;}}}}catch(_0x307ba0){console[_0x34cf85(0x17c)](_0x307ba0);}});

/*
{
   pattern: "delete",
   type: "notes",
}
 */