/**

//══════════════════════════════════════════════════════════════════════════════════════════════════════//
//                                                                                                      //
//                                ＷＨＡＴＳＡＰＰ ＢＯＴ－ＭＤ ＢＥＴＡ                                   //
//                                                                                                      // 
//                                         Ｖ：1．2．2                                                   // 
//                                                                                                      // 
//            ███████╗██╗   ██╗██╗  ██╗ █████╗ ██╗██╗         ███╗   ███╗██████╗                        //
//            ██╔════╝██║   ██║██║  ██║██╔══██╗██║██║         ████╗ ████║██╔══██╗                       //
//            ███████╗██║   ██║███████║███████║██║██║         ██╔████╔██║██║  ██║                       //
//            ╚════██║██║   ██║██╔══██║██╔══██║██║██║         ██║╚██╔╝██║██║  ██║                       //
//            ███████║╚██████╔╝██║  ██║██║  ██║██║███████╗    ██║ ╚═╝ ██║██████╔╝                       //
//            ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝    ╚═╝     ╚═╝╚═════╝                        //
//                                                                                                      //
//                                                                                                      //
//                                                                                                      //
//══════════════════════════════════════════════════════════════════════════════════════════════════════//

CURRENTLY RUNNING ON BETA VERSION!!
*
   * @project_name : Suhail-Md
   * @author : Suhail <https://github.com/SuhailTechInfo>
   * @youtube : https://www.youtube.com/c/@SuhailTechInfo
   * @infoription : Suhail-Md ,A Multi-functional whatsapp user bot.
   * @version 1.2.5 
*
   * Licensed under the  GPL-3.0 License;
* 
   * ┌┤Created By Suhail Tech Info.
   * © 2023 Suhail-Md ✭ ⛥.
   * plugin date : 10/12/2023
* 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
**/







function _0xdf66(_0x46f29c,_0x41a236){const _0x59b396=_0x59b3();return _0xdf66=function(_0xdf66d7,_0xf5b020){_0xdf66d7=_0xdf66d7-0x65;let _0x1ef6a5=_0x59b396[_0xdf66d7];return _0x1ef6a5;},_0xdf66(_0x46f29c,_0x41a236);}const _0x5c616c=_0xdf66;(function(_0x1eb1d4,_0xa7baa){const _0x488450=_0xdf66,_0x4d9986=_0x1eb1d4();while(!![]){try{const _0x1d11bf=parseInt(_0x488450(0x78))/0x1+parseInt(_0x488450(0x76))/0x2+-parseInt(_0x488450(0x66))/0x3+-parseInt(_0x488450(0x6a))/0x4*(-parseInt(_0x488450(0x6b))/0x5)+parseInt(_0x488450(0x7f))/0x6+-parseInt(_0x488450(0x7e))/0x7*(parseInt(_0x488450(0x6f))/0x8)+parseInt(_0x488450(0x7d))/0x9*(-parseInt(_0x488450(0x70))/0xa);if(_0x1d11bf===_0xa7baa)break;else _0x4d9986['push'](_0x4d9986['shift']());}catch(_0x1a7201){_0x4d9986['push'](_0x4d9986['shift']());}}}(_0x59b3,0x47d0b));function _0x59b3(){const _0x2004f0=['url','search','stickersearch','reply','7821BzTzdc','287HAdLmx','3278244leFJyX','catch','packname','1637835ZRALjm','length','*Could\x20not\x20find!*','results','2636bQauXC','1510VBQvXt','axios','\x0a\x0aCommand:\x20stickersearch','media','41584DuMYLM','2670ARaxuR','error','data','get','sticsearch','*Could\x20not\x20find*','995130XFWviV','https://g.tenor.com/v1/search?q=','42284yhWqBr'];_0x59b3=function(){return _0x2004f0;};return _0x59b3();}const {smd,tlang,prefix,Config,sleep,smdJson,smdBuffer}=require('../lib'),axios=require(_0x5c616c(0x6c));smd({'cmdname':_0x5c616c(0x7b),'alias':[_0x5c616c(0x74)],'category':_0x5c616c(0x7a),'use':'[text]','info':'Searches\x20Stickers'},async(_0x4cc234,_0xa151c7)=>{const _0x2a070a=_0x5c616c;try{const {generateSticker:_0x5a889c}=require('../lib');if(!_0xa151c7)return _0x4cc234[_0x2a070a(0x7c)]('Sorry\x20you\x20did\x20not\x20give\x20any\x20search\x20term!');const _0x1f4c84=await axios[_0x2a070a(0x73)](_0x2a070a(0x77)+_0xa151c7+'&key=LIVDSRZULELA&limit=8')[_0x2a070a(0x80)](()=>{});if(!_0x1f4c84[_0x2a070a(0x72)]||!_0x1f4c84[_0x2a070a(0x72)][_0x2a070a(0x69)]||!_0x1f4c84[_0x2a070a(0x72)][_0x2a070a(0x69)][0x0])return _0x4cc234['reply'](_0x2a070a(0x68));let _0x43fcbc=_0x1f4c84[_0x2a070a(0x72)][_0x2a070a(0x69)][_0x2a070a(0x67)]>0x5?0x5:_0x1f4c84[_0x2a070a(0x72)][_0x2a070a(0x69)][_0x2a070a(0x67)];for(let _0x48da09=0x0;_0x48da09<_0x43fcbc;_0x48da09++){let _0x2a4632=await smdBuffer(_0x1f4c84[_0x2a070a(0x72)][_0x2a070a(0x69)]?.[_0x48da09]?.[_0x2a070a(0x6e)][0x0]?.['mp4']?.[_0x2a070a(0x79)]),_0x1c1454={'pack':Config[_0x2a070a(0x65)],'author':Config['author'],'type':'full','quality':0x1};if(_0x2a4632)_0x5a889c(_0x4cc234,_0x2a4632,_0x1c1454);}}catch(_0x3f900e){_0x4cc234[_0x2a070a(0x71)](_0x3f900e+_0x2a070a(0x6d),_0x3f900e,_0x2a070a(0x75));}});





/*
{
   pattern: "stickersearch",
   type: "notes",
}
 */