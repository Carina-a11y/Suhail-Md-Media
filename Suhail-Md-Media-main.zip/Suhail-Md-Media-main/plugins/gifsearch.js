/**

//══════════════════════════════════════════════════════════════════════════════════════════════════════//
//                                                                                                      //
//                                ＷＨＡＴＳＡＰＰ ＢＯＴ－ＭＤ ＢＥＴＡ                                   //
//                                                                                                      // 
//                                         Ｖ：1．2．2                                                   // 
//                                                                                                      // 
//            ███████╗██╗   ██╗██╗  ██╗ █████╗ ██╗██╗         ███╗   ███╗██████╗                        //
//            ██╔════╝██║   ██║██║  ██║██╔══██╗██║██║         ████╗ ████║██╔══██╗                       //
//            ███████╗██║   ██║███████║███████║██║██║         ██╔████╔██║██║  ██║                       //
//            ╚════██║██║   ██║██╔══██║██╔══██║██║██║         ██║╚██╔╝██║██║  ██║                       //
//            ███████║╚██████╔╝██║  ██║██║  ██║██║███████╗    ██║ ╚═╝ ██║██████╔╝                       //
//            ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝    ╚═╝     ╚═╝╚═════╝                        //
//                                                                                                      //
//                                                                                                      //
//                                                                                                      //
//══════════════════════════════════════════════════════════════════════════════════════════════════════//

CURRENTLY RUNNING ON BETA VERSION!!
*
   * @project_name : Suhail-Md
   * @author : Suhail <https://github.com/SuhailTechInfo>
   * @youtube : https://www.youtube.com/c/@SuhailTechInfo
   * @infoription : Suhail-Md ,A Multi-functional whatsapp user bot.
   * @version 1.2.5 
*
   * Licensed under the  GPL-3.0 License;
* 
   * ┌┤Created By Suhail Tech Info.
   * © 2023 Suhail-Md ✭ ⛥.
   * plugin date : 20/12/2023
* 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
**/






const _0xbf7967=_0x126c;function _0x126c(_0x1b0bbd,_0x5206f2){const _0x46988e=_0x4698();return _0x126c=function(_0x126ccc,_0x2a06c8){_0x126ccc=_0x126ccc-0x1ca;let _0x5d86d3=_0x46988e[_0x126ccc];return _0x5d86d3;},_0x126c(_0x1b0bbd,_0x5206f2);}(function(_0x150362,_0x54add6){const _0x1cef6b=_0x126c,_0x125750=_0x150362();while(!![]){try{const _0x43ccbe=-parseInt(_0x1cef6b(0x1db))/0x1*(parseInt(_0x1cef6b(0x1e1))/0x2)+parseInt(_0x1cef6b(0x1dc))/0x3+-parseInt(_0x1cef6b(0x1d4))/0x4*(-parseInt(_0x1cef6b(0x1df))/0x5)+parseInt(_0x1cef6b(0x1cf))/0x6+-parseInt(_0x1cef6b(0x1d6))/0x7*(-parseInt(_0x1cef6b(0x1d5))/0x8)+parseInt(_0x1cef6b(0x1de))/0x9*(parseInt(_0x1cef6b(0x1dd))/0xa)+-parseInt(_0x1cef6b(0x1cb))/0xb;if(_0x43ccbe===_0x54add6)break;else _0x125750['push'](_0x125750['shift']());}catch(_0x4fe958){_0x125750['push'](_0x125750['shift']());}}}(_0x4698,0x33efc));const {smd,tlang,prefix,Config,sleep,getBuffer,smdJson,smdBuffer}=require(_0xbf7967(0x1e6));function _0x4698(){const _0x4ac599=['send','\x0a\x0aCommand:\x20gifsearch','search','https://g.tenor.com/v1/search?q=','../lib','results','axios','gifsearch','length','tenor','Searches\x20gif','5385391aTAiDa','*Could\x20not\x20find*','error','data','1116846FCEohL','&key=LIVDSRZULELA&limit=8','smdvid','catch','[text]','5932wjcFWc','152upjvow','7042kRhGRX','reply','Sorry\x20you\x20did\x20not\x20give\x20any\x20search\x20term!','caption','media','2xmFRaz','677679MAFnKf','2760mdBQlD','8010AIgsFn','1255OZaaEe','get','346708ygYSEE'];_0x4698=function(){return _0x4ac599;};return _0x4698();}smd({'cmdname':_0xbf7967(0x1e9),'alias':['gify',_0xbf7967(0x1eb)],'category':_0xbf7967(0x1e4),'use':_0xbf7967(0x1d3),'info':_0xbf7967(0x1ca)},async(_0x483f63,_0x5e7b36)=>{const _0x1007f9=_0xbf7967;try{if(!_0x5e7b36)return _0x483f63[_0x1007f9(0x1d7)](_0x1007f9(0x1d8));const _0x4da793=require(_0x1007f9(0x1e8)),_0x1abfb4=await _0x4da793[_0x1007f9(0x1e0)](_0x1007f9(0x1e5)+_0x5e7b36+_0x1007f9(0x1d0))[_0x1007f9(0x1d2)](()=>{});if(!_0x1abfb4[_0x1007f9(0x1ce)]||!_0x1abfb4['data'][_0x1007f9(0x1e7)]||!_0x1abfb4[_0x1007f9(0x1ce)][_0x1007f9(0x1e7)][0x0])return _0x483f63['reply'](_0x1007f9(0x1cc));let _0xf0dc5b=_0x1abfb4[_0x1007f9(0x1ce)][_0x1007f9(0x1e7)][_0x1007f9(0x1ea)]>0x5?0x5:_0x1abfb4[_0x1007f9(0x1ce)][_0x1007f9(0x1e7)][_0x1007f9(0x1ea)];for(let _0x344f87=0x0;_0x344f87<_0xf0dc5b;_0x344f87++){_0x483f63[_0x1007f9(0x1e2)](_0x1abfb4[_0x1007f9(0x1ce)][_0x1007f9(0x1e7)]?.[_0x344f87]?.[_0x1007f9(0x1da)][0x0]?.['mp4']?.['url'],{'caption':Config[_0x1007f9(0x1d9)],'gifPlayback':!![]},_0x1007f9(0x1d1),_0x483f63);}}catch(_0x3ae817){_0x483f63[_0x1007f9(0x1cd)](_0x3ae817+_0x1007f9(0x1e3),_0x3ae817,'*Could\x20not\x20find*');}});










/*
{
   pattern: "gifsearch",
   type: "notes",
}
 */