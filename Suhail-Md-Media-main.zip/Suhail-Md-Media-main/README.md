# Suhail-Md-Media




<h1 align="center"> Suhail Md Plugins </h1>
<div align="center">
<br /> 
<p align="center"> <img src="https://komarev.com/ghpvc/?username=Suhail&label=Visitors%20count&color=10d9c3&style=plastic" alt="Suhail-plugin-list" /> </p>


ᴄʟɪᴄᴋ ᴡᴀ ʟᴏɢᴏ ᴛᴏ ᴊᴏɪɴ sᴜᴘᴘᴏʀᴛ ɢʀᴏᴜᴘ 👇 
<br> [![join](https://github.com/Alien-alfa/PublicBot/blob/main/wlogo.svg.png)](https://whatsapp.com/channel/0029Va9thusJP20yWxQ6N643)
  <div align="center"  >
<h4 align="center">Plugins</h1>

---

- Create your own plugins and join group to add that plugin in repo.





---
<h4 align="center"> Live </h1>

Live time
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/live.js
```
- ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : You can know which time is Now
---

<h4 align="center">  Teddy  </h1>

SEnds  Animated Teddy 
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/teddy.js
```
---
<h4 align="center">  auto forward (EditAble)</h1>

AUTO Forward Message
```
https://gist.githubusercontent.com/SuhailTechInfo/5691ba46fffcb311da7ea77f2db2cdc8
```
- Editable Plugin : fork it, and edit your information!
---

<h4 align="center">  Fd (EditAble)</h1>

Forward Message with editable Preview
```
https://gist.githubusercontent.com/SuhailTechInfo/1c29c84bd1890320d587c04e5c24a429
```
- Editable Plugin : fork it, and fill your information!
---
---
<h4 align="center">  Intro</h1>

Sends Your Intro
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/intro.js
```
- Editable Plugin : fork it, and fill your information!
---

<h4 align="center">  Cricket </h1>

scores & cricket
```
https://gist.githubusercontent.com/SuhailTechInfo/8c0c6ea1321edc312aacdc416e3451c5/raw
```
- ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : get live cricket match scores results
---

<h4 align="center">  Notes </h1>

save , read and delete notes
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/notes.js
```
- ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Save notes in server side
---

<h4 align="center">  AutoReact </h1>

Auto React Messages
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/areact.js
```
- Auto React Messages/Cmds/Alls
---

<h4 align="center">  AntiCall </h1>

Decline Call From Spammers
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/anticall.js
```
- Auto Decline calls, from selected numbers, Or also Decline Call from All
---

<h4 align="center">  SSaver </h1>

Status Saver.
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/ssaver.js
```
- Save Someones Whatsapp Story,

---

<h4 align="center">  LevelUp </h1>

Rank, Profile , Leaderboard, LevelUp
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/rank.js
```
- Mongodb Require To Access these cmds
---

<h4 align="center">  AntiViewOnve </h1>

Auto Download ViewOnce Messages.
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/antivv.js
```

---

<h4 align="center">  AntiDelete </h1>

DETECT AND SENDS DELETED MESSAGES IN CHAT
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/delete.js
```

---



<h4 align="center">  ReactionPack </h1>

- send anime reactions.
```
https://gist.githubusercontent.com/SuhailTechInfo/46087297afd330ad280d7cfc74eccbf8/raw
```
 20+ commands Pack for randome anime reaction
---

<h4 align="center">  Audio Editor </h1>


```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/audio.js
```
- change audio in different varity
---

<h4 align="center"> TextPro Logo </h1>

Textpro logo list
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/logo.js
```
- Text to Image Logo creator
---


<h4 align="center"> Pubg Logo </h1>

create pubg logo
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/pubg.js
```
- Generate Pubg Mobile logos
---


<h4 align="center"> cat </h1>

Randome Cat
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/cat.js
```
- Send Randome Cat Images In Chat

---

<h4 align="center"> Dog </h1>

Randome Dog Videos
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/dog.js
```
- Sends Randome Dog Video Or Image
---

<h4 align="center"> FakeReply </h1>

Send Fake Reply by Given number and message Type
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/fakereply.js
```

---

<h4 align="center"> Hack </h1>

Hacking Prank
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/hack.js
```

---

---

<h4 align="center"> GetAll </h1>

Get all jids
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/getall.js
```
- Get all member,all groups and all pm user jids
---



---

<h4 align="center"> Editor-Pack </h1>

 Media Editor
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/xmedia.js
```
-  40+ features to edit media messages, image,audio and video editor
---

---

<h4 align="center"> DelSpam </h1>

 Delete Multitple messages 
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/delspam.js
```
-  Delete messages of a user from Group!
---

---

<h4 align="center"> StickerSearch </h1>

 Search Stickers
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/stickersearch.js
```
-  Delete messages of a user from Group!
---



---

<h4 align="center"> GifSearch </h1>

 Search gif Videos
```
https://raw.githubusercontent.com/SuhailTechInfo/Suhail-Md-Media/main/plugins/gifsearch.js
```
-  Delete messages of a user from Group!
---


---

<h4 align="center"> Insta Downloader </h1>

 Dowanload Insta videos
```
https://gist.githubusercontent.com/SuhailTechInfo/4ecf80d5dfd264920117ca44a1917fe8/raw
```
- USAGE : .insta insta_video_url
---
---

<h4 align="center"> gdrive Downloader </h1>

 Dowanload google drive files
```
https://gist.githubusercontent.com/SuhailTechInfo/4ecf80d5dfd264920117ca44a1917fe8/raw
```
- USAGE : .gdrive Google_drive_url
---
---

<h4 align="center"> fromurl Downloader </h1>

 Dowanload files from url
```
https://gist.githubusercontent.com/SuhailTechInfo/4ecf80d5dfd264920117ca44a1917fe8/raw
```
- USAGE : .download file_url
---

